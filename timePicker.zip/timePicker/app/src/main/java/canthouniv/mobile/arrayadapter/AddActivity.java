package canthouniv.mobile.arrayadapter;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {
    private static final String TAG = "오류";
    //EditText etHour;
    //EditText etMinute;
    TimeDBHelper dbHelper;
    TimePicker mTimePicker;
    Calendar mCalendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

       // etHour = findViewById(R.id.etHour);
       // etMinute = findViewById(R.id.etMinute);

        dbHelper = new TimeDBHelper(this);
    }

    public void onClick(View v){
        switch(v.getId()){
            case R.id.btn_add:
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues value = new ContentValues();

                int hour, min;

                if(Build.VERSION.SDK_INT >= 23) {
                    hour = mTimePicker.getHour();
                    min = mTimePicker.getMinute();
                } else {
                    hour = mTimePicker.getCurrentHour();
                    min = mTimePicker.getCurrentMinute();
                }
                value.put(TimeDBHelper.COL_HOUR, hour);
                value.put(TimeDBHelper.COL_MINUTE, min);

                //value.put(TimeDBHelper.COL_HOUR, etHour.getText().toString());
                //value.put(TimeDBHelper.COL_MINUTE, etMinute.getText().toString());

                long count = db.insert(TimeDBHelper.TABLE_NAME, null, value);

                if(count > 0) {
                    Log.d(TAG, "들어는 가니?");
                    setResult(RESULT_OK, null);
                    dbHelper.close();
                    finish();
                } else {
                    Toast.makeText(this, "새로운 알람 추가 실패!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    dbHelper.close();
                }
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
    }
}