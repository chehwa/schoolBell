package canthouniv.mobile.arrayadapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

    public class MyAdapter extends BaseAdapter {
        private Context context;
        private int layout;
        private ArrayList<Time> TimeList;
        private LayoutInflater layoutInflater;

    public MyAdapter(Context context, int layout, ArrayList<Time> timeList) {
        this.context = context;
        this.layout = layout;
        this.TimeList = timeList;
        layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return TimeList.size();
    }

    @Override
    public Object getItem(int position) {
        return TimeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return TimeList.get(position).get_id();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        ViewHolder holder;

        if (convertView == null) {
            convertView = layoutInflater.inflate(layout, parent, false);

            holder = new ViewHolder();
            holder.timeNo = (TextView)convertView.findViewById(R.id.timeNo);
            holder.timeHour = (TextView)convertView.findViewById(R.id.timeHour);
            holder.timeMinute = (TextView)convertView.findViewById(R.id.timeMinute);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder)convertView.getTag();
        }

        holder.timeNo.setText(Long.valueOf(TimeList.get(pos).get_id()).toString());
        holder.timeHour.setText(TimeList.get(pos).getHour());
        holder.timeMinute.setText(TimeList.get(pos).getMinute());

        return convertView;
    }

    static class ViewHolder {
        TextView timeNo;
        TextView timeHour;
        TextView timeMinute;
    }
}