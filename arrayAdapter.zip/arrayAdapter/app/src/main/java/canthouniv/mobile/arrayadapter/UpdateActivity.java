package canthouniv.mobile.arrayadapter;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    EditText etHour;
    EditText etMinute;

    TimeDBHelper dbHelper;

    Time timeDto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        dbHelper = new TimeDBHelper(this);

        etHour = findViewById(R.id.etHour);
        etMinute = findViewById(R.id.etMinute);

        Intent intent = getIntent();
        timeDto = (Time) intent.getSerializableExtra("timeDto");

        etHour.setText(timeDto.getHour());
        etMinute.setText(timeDto.getMinute());
    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_update:
                String hour = etHour.getText().toString();
                String minute = etMinute.getText().toString();

                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues row = new ContentValues();
                row.put(TimeDBHelper.COL_HOUR, hour);
                row.put(TimeDBHelper.COL_MINUTE, minute);

                String whereClause = TimeDBHelper.COL_ID + "=?";
                String[] whereArgs = new String[] { String.valueOf(timeDto.get_id()) };

                long count = db.update(TimeDBHelper.TABLE_NAME, row, whereClause, whereArgs);

                if(count > 0){
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("result","timeDto");
                    setResult(RESULT_OK, resultIntent);
                    dbHelper.close();
                    finish();
                } else {
                    Toast.makeText(this, "알람 수정 실패!", Toast.LENGTH_SHORT).show();

                    dbHelper.close();
                }
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                break;
        }
        finish();
    }
}