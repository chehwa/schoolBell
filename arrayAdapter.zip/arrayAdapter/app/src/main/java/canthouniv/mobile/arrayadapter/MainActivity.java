package canthouniv.mobile.arrayadapter;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    final static String TAG = "MainActivity";
    final int REQ_CODE = 100;
    final int UPDATE_CODE = 200;

    private ArrayList<Time> timeList;
    private MyAdapter myAdapter;
    private ListView listView;

    TimeDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "보임?onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new TimeDBHelper(this);

        timeList = new ArrayList<Time>();
        myAdapter = new MyAdapter(this, R.layout.custom_adapter_view, timeList);

        listView = (ListView) findViewById(R.id.my_listView);

        listView.setAdapter(myAdapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long id){
                final int position = pos;

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("삭제 확인");
                builder.setMessage(timeList.get(position).get_id() + "을(를) 삭제하시겠습니까?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SQLiteDatabase db = dbHelper.getWritableDatabase();
                        String whereClause = TimeDBHelper.COL_ID + "=?";
                        String[] whereArgs = new String[] { String.valueOf(timeList.get(position).get_id()) };
                        db.delete(TimeDBHelper.TABLE_NAME, whereClause, whereArgs);
                        dbHelper.close();

                        readAllTimes();
                        myAdapter.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("취소", null);
                builder.show();
                return true;
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
                Intent intent = new Intent(MainActivity.this, UpdateActivity.class);
                intent.putExtra("timeDto", timeList.get(pos));

                startActivityForResult(intent, UPDATE_CODE);
            }
        });
    }

    @Override
    protected void onResume(){
        super.onResume();
        readAllTimes();
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.option_add:
                Intent intent = new Intent(this, AddActivity.class);
                startActivity(intent);
                Log.d(TAG, "보임?add");
                break;
            case R.id.option_copyright:
                Toast.makeText(this, "김예진 민체화", Toast.LENGTH_SHORT).show();
                break;
            case R.id.option_close:
                finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void readAllTimes(){
        timeList.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TimeDBHelper.TABLE_NAME, null);

        while(cursor.moveToNext()){
            long id = cursor.getInt(cursor.getColumnIndex(TimeDBHelper.COL_ID));
            String hour = cursor.getString(cursor.getColumnIndex(TimeDBHelper.COL_HOUR));
            String minute = cursor.getString(cursor.getColumnIndex(TimeDBHelper.COL_MINUTE));

            timeList.add( new Time(id, hour, minute) );
        }
        cursor.close();
        dbHelper.close();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode ==  REQ_CODE){
            switch(resultCode){
                case RESULT_OK:
                    Toast.makeText(this, "시간 추가 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "시간 추가 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        } else if (requestCode == UPDATE_CODE) {
            switch(resultCode){
                case RESULT_OK:
                    Toast.makeText(this, "시간 수정 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "시간 수정 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }
}
